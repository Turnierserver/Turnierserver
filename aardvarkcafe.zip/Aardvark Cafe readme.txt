Aardvark Caf� computer font v1.0
�2000 Harold Lohner
HLohner@aol.com
http://members.aol.com/fontner

FREEWARE

Based on the Hard Rock Caf� logo.